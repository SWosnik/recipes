---
layout: default
title: "Spagettie mit Zucchini-Bolognese"
---
# Spagettie mit Zucchini-Bolognese
## Zutaten
